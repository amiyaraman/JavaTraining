package own.practice.one;



public class Ownpractice {
        
         
       //  Employee e = new Employee(1, 45000, "Tarun", 12);
	}


