package collections;
import java.util.*;
public class HashSetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> s = new HashSet<String>();
		s.add("Tarun");
		s.add("Bhargav");
		s.add("Varun");
		s.add("Ketan");
		s.add("Avni");
		
		System.out.println(s);
		
	}

}
